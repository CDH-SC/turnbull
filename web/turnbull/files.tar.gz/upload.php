<?php
/**
 * @file upload.php
 * Upload/Overwrite XML files.
 */

// Error Reporting
error_reporting(E_ALL);
ini_set("display_errors", 1);

// Definitions
define("ROOT_FOLDER", "http://" . $_SERVER["HTTP_HOST"] . "/turnbull/");

if (isset($_POST["folder"]) && isset($_FILES["files"])) {

}

function converter($input) {
  if ($input === "america") {
    return "Poems in America";
  } else if ($input === "appendices") {
    return "Appendices";
  } else if ($input === "burns") {
    return "Poems from Burn's Letter (1793)";
  } else if ($input === "poems") {
    return "<em>Poems</em> (1794)";
  } else if ($input === "poetical") {
    return "<em>Poetical Essays</em> (1788)";
  }
}


// $target_dir = "uploads/";
// $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
// $uploadOk = 1;
// $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// // Check if image file is a actual image or fake image
// if(isset($_POST["submit"])) {
//     $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
//     if($check !== false) {
//         echo "File is an image - " . $check["mime"] . ".";
//         $uploadOk = 1;
//     } else {
//         echo "File is not an image.";
//         $uploadOk = 0;
//     }
// }

// if (isset($_POST["folder"], isset($_POST["file"]))) {

//   return;
// }

?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">

  <title>Upload - Turnbull Project</title>

  <link rel="stylesheet" href="<?php print ROOT_FOLDER; ?>css/bootstrap.min.css">
</head>
<body>
  <header class="container">
    <div class="row page-header">
      <div class="col-xs-12">
        <h1>XML File Upload</h1>
        <a href="<?php print ROOT_FOLDER; ?>upload" class="btn btn-sm btn-primary">Refresh</a>
      </div>
    </div>
  </header>

  <div class="container">
    <div class="row">
      <div class="col-xs-12">
        <form class="form-horizontal" action="<?php print ROOT_FOLDER; ?>upload" method="POST" enctype="multipart/form-data">
          <fieldset>
            <div class="form-group">
              <label for="folder" class="control-label col-xs-2">Category</label>
              <div class="col-xs-10">
                <select id="folder" name="folder" class="form-control" required="">
                  <option value="select">Select a Category</option>
                  <?php foreach (array("america" => "Poems in America", "appendices" => "Appendices", "burns" => "Poems from Burns's Letter (1793)", "poems" => "<em>Poems</em> (1794)", "poetical" => "<em>Poetical Essays</em> (1788)") as $value=>$text): ?>
                    <option value="<?php print $value; ?>"><?php print $text; ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
            </div>

            <div class="form-group">
              <label for="files" class="control-label col-xs-2">File</label>
              <div class="col-xs-10">
                <input type="file" id="files" name="files[]" multiple="" accept="text/xml">
              </div>
            </div>

            <div class="form-group">
              <label for="password" class="control-label col-xs-2">Password</label>
              <div class="col-xs-10">
                <input type="password" id="password" name="password">
              </div>
            </div>

            <div class="form-group">
              <div class="col-xs-2 center-block">
                <button type="submit" class="btn btn-primary col-xs-12">Upload</button>
              </div>
            </div>
          </fieldset>
        </form>
      </div>
    </div>

    <?php if (isset($_POST["folder"], $_FILES["files"], $_POST["password"])): ?>
      <div class="row">
        <div class="col-xs-12">
          <?php if ($_POST["folder"] === "select"): ?>
            <div class="alert alert-warning">
              <p><i class="glyphicon glyphicon-exclamation-sign"></i> Please select a category.</p>
            </div>
          <?php elseif (trim($_FILES["files"]["name"][0]) === ""): ?>
            <div class="alert alert-warning">
              <p><i class="glyphicon glyphicon-exclamation-sign"></i> Please select at least one file.</p>
            </div>
          <?php elseif ($_POST["password"] !== "Andromeda940"): ?>
            <div class="alert alert-warning">
              <p><i class="glyphicon glyphicon-exclamation-sign"></i> Please input the correct password.</p>
            </div>
          <?php else: ?>
            <?php

            ?>
            <div class="alert alert-success">
              <p><i class="glyphicon glyphicon-check"></i> The following uploads for <?php print converter($_POST["folder"]); ?> were successful.</p>
              <ul>
                <?php foreach ($_FILES["files"]["name"] as $name): ?>
                  <li><?php print $name; ?></li>
                <?php endforeach; ?>
              </ul>
            </div>
          <?php endif; ?>
        </div>
      </div>
    <?php endif; ?>

    <div class="row">
      <div class="col-xs-4">
        <pre><?php print print_r($_POST, true); ?></pre>
      </div>

      <div class="col-xs-4">
        <pre><?php print print_r($_GET, true); ?></pre>
      </div>

      <div class="col-xs-4">
        <pre><?php print print_r($_FILES, true); ?></pre>
      </div>
    </div>
  </div>

  <script src="<?php print ROOT_FOLDER; ?>js/jquery.min.js"></script>
</body>
</html>
